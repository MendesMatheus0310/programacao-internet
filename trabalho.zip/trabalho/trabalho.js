// Aguarda o carregamento completo do DOM antes de executar o script
document.addEventListener('DOMContentLoaded', () => {

    // Função auxiliar para formatar valores como moeda brasileira (Real)
    const formatarMoeda = (valor) => {
        return valor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    };

    // Função para exibir resultados (generalizada)
    const exibirResultado = (elemento, mensagem, tipo) => {
        elemento.className = `resultado ${tipo}`;
        elemento.innerHTML = mensagem;
    };

    // --- Lógica do Exercício 1: Triângulo ---
    const btnTriangulo = document.getElementById('btnTriangulo');
    if (btnTriangulo) {
        btnTriangulo.addEventListener('click', () => {
            const x = parseFloat(document.getElementById('ladoX').value);
            const y = parseFloat(document.getElementById('ladoY').value);
            const z = parseFloat(document.getElementById('ladoZ').value);
            const resultadoDiv = document.getElementById('resultadoTriangulo');

            if (isNaN(x) || isNaN(y) || isNaN(z) || x <= 0 || y <= 0 || z <= 0) {
                exibirResultado(resultadoDiv, 'Por favor, insira valores numéricos positivos para todos os lados.', 'erro');
                return;
            }

            if (x < y + z && y < x + z && z < x + y) {
                let tipoTriangulo;
                if (x === y && y === z) {
                    tipoTriangulo = '<strong>Equilátero</strong>';
                } else if (x === y || x === z || y === z) {
                    tipoTriangulo = '<strong>Isósceles</strong>';
                } else {
                    tipoTriangulo = '<strong>Escaleno</strong>';
                }
                exibirResultado(resultadoDiv, `É um triângulo ${tipoTriangulo}.`, 'sucesso');
            } else {
                exibirResultado(resultadoDiv, 'Os valores informados não formam um triângulo.', 'erro');
            }
        });
    }

    // --- Lógica do Exercício 2: IMC ---
    const btnIMC = document.getElementById('btnIMC');
    if (btnIMC) {
        btnIMC.addEventListener('click', () => {
            const peso = parseFloat(document.getElementById('peso').value);
            const altura = parseFloat(document.getElementById('altura').value);
            const resultadoDiv = document.getElementById('resultadoIMC');
            
            if (isNaN(peso) || isNaN(altura) || peso <= 0 || altura <= 0) {
                exibirResultado(resultadoDiv, 'Por favor, insira peso e altura válidos.', 'erro');
                return;
            }

            const imc = peso / (altura * altura);
            let classificacao = '';
            if (imc < 18.5) classificacao = 'Abaixo do peso';
            else if (imc < 25) classificacao = 'Peso normal';
            else if (imc < 30) classificacao = 'Sobrepeso';
            else if (imc < 35) classificacao = 'Obesidade grau 1';
            else if (imc < 40) classificacao = 'Obesidade grau 2';
            else classificacao = 'Obesidade grau 3';

            exibirResultado(resultadoDiv, `Seu IMC é <strong>${imc.toFixed(2)}</strong>. Classificação: <strong>${classificacao}</strong>.`, 'sucesso');
        });
    }

    // --- Lógica do Exercício 3: Impostos Veículo ---
    const btnImposto = document.getElementById('btnImposto');
    if(btnImposto) {
        btnImposto.addEventListener('click', () => {
            const ano = parseInt(document.getElementById('anoVeiculo').value);
            const valor = parseFloat(document.getElementById('valorVeiculo').value);
            const resultadoDiv = document.getElementById('resultadoImposto');

            if (isNaN(ano) || isNaN(valor) || ano <= 1886 || valor <= 0) { // 1886 é o ano do primeiro carro
                exibirResultado(resultadoDiv, 'Por favor, insira um ano e valor válidos.', 'erro');
                return;
            }

            const taxa = (ano < 1990) ? 0.01 : 0.015;
            const imposto = valor * taxa;
            
            exibirResultado(resultadoDiv, `O valor do imposto a ser pago é de <strong>${formatarMoeda(imposto)}</strong>.`, 'sucesso');
        });
    }
    
    // --- Lógica do Exercício 4: Salário ---
    const btnSalario = document.getElementById('btnSalario');
    if (btnSalario) {
        btnSalario.addEventListener('click', () => {
            const codigo = document.getElementById('codigoCargo').value.trim();
            const salario = parseFloat(document.getElementById('salarioAtual').value);
            const resultadoDiv = document.getElementById('resultadoSalario');

            if (codigo === '' || isNaN(salario) || salario <= 0) {
                exibirResultado(resultadoDiv, 'Por favor, insira um código e um salário válido.', 'erro');
                return;
            }

            let percentual;
            switch (codigo) {
                case '101': percentual = 0.10; break;
                case '102': percentual = 0.20; break;
                case '103': percentual = 0.30; break;
                default: percentual = 0.40; break;
            }

            const aumento = salario * percentual;
            const novoSalario = salario + aumento;

            const mensagem = `
                Salário Antigo: ${formatarMoeda(salario)}<br>
                Novo Salário: ${formatarMoeda(novoSalario)}<br>
                Diferença: ${formatarMoeda(aumento)}
            `;
            exibirResultado(resultadoDiv, mensagem, 'sucesso');
        });
    }

    // --- Lógica do Exercício 5: Crédito Bancário ---
    const btnCredito = document.getElementById('btnCredito');
    if(btnCredito) {
        btnCredito.addEventListener('click', () => {
            const saldo = parseFloat(document.getElementById('saldoMedio').value);
            const resultadoDiv = document.getElementById('resultadoCredito');

            if (isNaN(saldo) || saldo < 0) {
                exibirResultado(resultadoDiv, 'Por favor, insira um saldo médio válido.', 'erro');
                return;
            }

            let percentualCredito;
            if (saldo <= 200) percentualCredito = 0;
            else if (saldo <= 400) percentualCredito = 0.20;
            else if (saldo <= 600) percentualCredito = 0.30;
            else percentualCredito = 0.40;

            const valorCredito = saldo * percentualCredito;
            let mensagem;
            
            if (valorCredito > 0) {
                 mensagem = `Saldo Médio: ${formatarMoeda(saldo)}.<br>Valor do Crédito: <strong>${formatarMoeda(valorCredito)}</strong>.`;
            } else {
                 mensagem = `Saldo Médio: ${formatarMoeda(saldo)}.<br><strong>Nenhum crédito disponível</strong> para esta faixa de saldo.`;
            }
            exibirResultado(resultadoDiv, mensagem, 'sucesso');
        });
    }

    // --- Lógica do Exercício 6: Lanchonete ---
    const btnLanche = document.getElementById('btnLanche');
    if(btnLanche) {
        btnLanche.addEventListener('click', () => {
            const preco = parseFloat(document.getElementById('itemLanche').value);
            const quantidade = parseInt(document.getElementById('quantidadeLanche').value);
            const resultadoDiv = document.getElementById('resultadoLanche');

            if (isNaN(preco) || isNaN(quantidade) || quantidade <= 0) {
                exibirResultado(resultadoDiv, 'Por favor, selecione um item e informe uma quantidade válida.', 'erro');
                return;
            }
            
            const total = preco * quantidade;
            exibirResultado(resultadoDiv, `O valor total a pagar é: <strong>${formatarMoeda(total)}</strong>.`, 'sucesso');
        });
    }
    
    // --- Lógica do Exercício 7: Sistema de Vendas ---
    const btnPagamento = document.getElementById('btnPagamento');
    if(btnPagamento) {
        btnPagamento.addEventListener('click', () => {
            const preco = parseFloat(document.getElementById('precoProduto').value);
            const condicao = document.getElementById('condicaoPagamento').value;
            const resultadoDiv = document.getElementById('resultadoPagamento');

            if (isNaN(preco) || preco <= 0) {
                exibirResultado(resultadoDiv, 'Por favor, insira um preço de produto válido.', 'erro');
                return;
            }

            let precoFinal;
            switch(condicao) {
                case 'a': precoFinal = preco * 0.90; break;
                case 'b': precoFinal = preco * 0.85; break;
                case 'c': precoFinal = preco; break;
                case 'd': precoFinal = preco * 1.10; break;
            }
            
            exibirResultado(resultadoDiv, `O valor final a ser pago é <strong>${formatarMoeda(precoFinal)}</strong>.`, 'sucesso');
        });
    }

    // --- Lógica do Exercício 8: Pagamento de Professores ---
    const btnSalarioProfessor = document.getElementById('btnSalarioProfessor');
    if(btnSalarioProfessor) {
        btnSalarioProfessor.addEventListener('click', () => {
            const valorHora = parseFloat(document.getElementById('nivelProfessor').value);
            const horas = parseFloat(document.getElementById('horasAula').value);
            const resultadoDiv = document.getElementById('resultadoSalarioProfessor');

            if (isNaN(valorHora) || isNaN(horas) || horas <= 0) {
                exibirResultado(resultadoDiv, 'Por favor, informe uma quantidade de horas válida.', 'erro');
                return;
            }

            const salario = valorHora * horas * 4.5;
            
            exibirResultado(resultadoDiv, `O salário mensal do professor será de <strong>${formatarMoeda(salario)}</strong>.`, 'sucesso');
        });
    }
});