function calcularLitros() {
  const preco = parseFloat(document.getElementById("preco").value);
  const valor = parseFloat(document.getElementById("valor").value);
  const resultado = document.getElementById("resultado");

  if (isNaN(preco) || isNaN(valor) || preco <= 0 || valor < 0) {
    resultado.textContent = "Por favor, insira valores válidos.";
    return;
  }

  const litros = valor / preco;
  resultado.textContent = `Você conseguiu colocar ${litros.toFixed(2)} litros de gasolina no tanque.`;
}
