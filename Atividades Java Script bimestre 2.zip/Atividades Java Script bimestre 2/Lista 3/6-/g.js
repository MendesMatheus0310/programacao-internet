function calcularValor() {
  const precoPorQuilo = 12.00;
  const peso = parseFloat(document.getElementById("peso").value);
  const resultado = document.getElementById("resultado");

  if (isNaN(peso) || peso <= 0) {
    resultado.textContent = "Por favor, insira um peso válido.";
    return;
  }

  const valor = peso * precoPorQuilo;
  resultado.textContent = `O valor a pagar é R$ ${valor.toFixed(2)}.`;
}
