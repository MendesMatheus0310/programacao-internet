function calcularDistancia() {
  const x1 = parseFloat(document.getElementById("x1").value);
  const y1 = parseFloat(document.getElementById("y1").value);
  const x2 = parseFloat(document.getElementById("x2").value);
  const y2 = parseFloat(document.getElementById("y2").value);
  const resultado = document.getElementById("resultado");

  if (
    isNaN(x1) || isNaN(y1) ||
    isNaN(x2) || isNaN(y2)
  ) {
    resultado.textContent = "Por favor, preencha todos os campos com números válidos.";
    return;
  }

  const distancia = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
  resultado.textContent = `A distância entre os dois pontos é ${distancia.toFixed(2)} unidades.`;
}
