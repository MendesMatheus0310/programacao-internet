function calcularDias() {
  const nome = document.getElementById("nome").value.trim();
  const idade = parseInt(document.getElementById("idade").value);

  const resultado = document.getElementById("resultado");

  if (!nome || isNaN(idade) || idade < 0) {
    resultado.textContent = "Por favor, digite um nome e uma idade válidos.";
    return;
  }

  const diasDeVida = idade * 365;
  resultado.textContent = `${nome.toUpperCase()}, VOCÊ JÁ VIVEU ${diasDeVida} DIAS.`;
}
