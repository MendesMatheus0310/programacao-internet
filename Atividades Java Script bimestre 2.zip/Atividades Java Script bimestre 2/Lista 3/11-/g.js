function calcularSalario() {
  const salarioInicial = parseFloat(document.getElementById("salario").value);
  const resultado = document.getElementById("resultado");

  if (isNaN(salarioInicial) || salarioInicial < 0) {
    resultado.textContent = "Por favor, insira um salário válido (>= 0).";
    return;
  }

  const aumento = salarioInicial * 0.15;
  const salarioComAumento = salarioInicial + aumento;
  const descontoImposto = salarioComAumento * 0.08;
  const salarioFinal = salarioComAumento - descontoImposto;

  resultado.textContent = 
    `Salário inicial: R$ ${salarioInicial.toFixed(2)}\n` +
    `Salário com aumento de 15%: R$ ${salarioComAumento.toFixed(2)}\n` +
    `Salário final após desconto de 8% de impostos: R$ ${salarioFinal.toFixed(2)}`;
}
