function calcularArea() {
    const largura = document.getElementById('largura').value;
    const comprimento = document.getElementById('comprimento').value;
    const resultado = document.getElementById('resultado');

    if (largura > 0 && comprimento > 0) {
        const area = largura * comprimento;
        resultado.textContent = `A área do terreno é de ${area} m².`;
    } else {
        resultado.textContent = "Por favor, insira valores válidos para a largura e o comprimento.";
    }
}