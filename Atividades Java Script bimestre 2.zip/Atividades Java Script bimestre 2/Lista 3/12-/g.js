function separarNumero() {
  const num = document.getElementById("numero").value.trim();
  const resultado = document.getElementById("resultado");

  if (!num.match(/^\d{1,3}$/)) {
    resultado.textContent = "Por favor, insira um número inteiro entre 0 e 999.";
    return;
  }

  const numero = parseInt(num, 10);

  const centena = Math.floor(numero / 100);
  const dezena = Math.floor((numero % 100) / 10);
  const unidade = numero % 10;

  resultado.textContent =
    `CENTENA = ${centena}\n` +
    `DEZENA = ${dezena}\n` +
    `UNIDADE = ${unidade}`;
}
