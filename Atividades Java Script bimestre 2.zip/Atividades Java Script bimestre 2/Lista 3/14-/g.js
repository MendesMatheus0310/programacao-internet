function dividirConta() {
  const valorTotal = parseFloat(document.getElementById("valorConta").value);
  const resultado = document.getElementById("resultado");

  if (isNaN(valorTotal) || valorTotal < 0) {
    resultado.textContent = "Por favor, insira um valor válido da conta (>= 0).";
    return;
  }

  // Divisão ideal
  const divisao = valorTotal / 3;

  // Carlos e André pagam a parte inteira (sem centavos)
  const parteInteira = Math.floor(divisao);

  // Felipe paga o restante
  const valorFelipe = valorTotal - 2 * parteInteira;

  resultado.textContent =
    `Carlos deve pagar: R$ ${parteInteira.toFixed(2)}\n` +
    `André deve pagar: R$ ${parteInteira.toFixed(2)}\n` +
    `Felipe deve pagar: R$ ${valorFelipe.toFixed(2)}`;
}
