function calcularDias() {
  const dia = parseInt(document.getElementById("dia").value);
  const mes = parseInt(document.getElementById("mes").value);
  const resultado = document.getElementById("resultado");

  if (isNaN(dia) || isNaN(mes) || dia < 1 || dia > 30 || mes < 1 || mes > 12) {
    resultado.textContent = "Por favor, insira um dia (1-30) e mês (1-12) válidos.";
    return;
  }

  const diasPassados = (mes - 1) * 30 + dia;
  resultado.textContent = `Já se passaram ${diasPassados} dias desde o início do ano.`;
}
