function calcularTotal() {
  const qtdPequena = parseInt(document.getElementById("pequena").value) || 0;
  const qtdMedia = parseInt(document.getElementById("media").value) || 0;
  const qtdGrande = parseInt(document.getElementById("grande").value) || 0;

  const precoPequena = 10;
  const precoMedia = 12;
  const precoGrande = 15;

  const total = (qtdPequena * precoPequena) + (qtdMedia * precoMedia) + (qtdGrande * precoGrande);

  const resultado = document.getElementById("resultado");
  resultado.textContent = `O valor total arrecadado é R$ ${total.toFixed(2)}.`;
}
