function converterTempo() {
  const totalDias = parseInt(document.getElementById("dias").value);
  const resultado = document.getElementById("resultado");

  if (isNaN(totalDias) || totalDias < 0) {
    resultado.textContent = "Por favor, insira um número válido de dias (>= 0).";
    return;
  }

  const diasPorMes = 30;
  const mesesPorAno = 12;

  const anos = Math.floor(totalDias / (diasPorMes * mesesPorAno));
  const meses = Math.floor((totalDias % (diasPorMes * mesesPorAno)) / diasPorMes);
  const dias = totalDias % diasPorMes;

  resultado.textContent = `${anos} ano(s), ${meses} mês(es) e ${dias} dia(s).`;
}
