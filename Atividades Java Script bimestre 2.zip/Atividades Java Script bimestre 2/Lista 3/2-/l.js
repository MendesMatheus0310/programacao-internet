function calcularFerraduras() {
    const numeroDeCavalos = document.getElementById('cavalos').value;
    const resultado = document.getElementById('resultado');

    if (numeroDeCavalos > 0) {
        const totalFerraduras = numeroDeCavalos * 4;
        resultado.textContent = `Serão necessárias ${totalFerraduras} ferraduras para equipar ${numeroDeCavalos} cavalos.`;
    } else {
        resultado.textContent = "Por favor, insira um número de cavalos válido.";
    }
}