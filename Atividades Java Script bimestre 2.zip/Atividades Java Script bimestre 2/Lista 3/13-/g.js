function calcularArea() {
  const raio = parseFloat(document.getElementById("raio").value);
  const resultado = document.getElementById("resultado");

  if (isNaN(raio) || raio < 0) {
    resultado.textContent = "Por favor, insira um raio válido (maior ou igual a zero).";
    return;
  }

  const pi = 3.14;
  const area = pi * raio * raio;

  resultado.textContent = `A área da pizza é ${area.toFixed(2)} unidades².`;
}
