let InputNum1 = document.querySelector("#InputNum1")
let resultado2 = document.querySelector("#resultado2")
let resultado3 = document.querySelector("#resultado3")
let resultado4 = document.querySelector("#resultado4")
let btSomar = document.querySelector("#btSomar")

function somar(){

let num1= Number(InputNum1.value);
let resultado2= (num1);
let resultado4= (resultado2*0.01)

resultado3.textContent = (num1 + resultado4 );

}

btSomar.onclick = function(){
    somar();


}