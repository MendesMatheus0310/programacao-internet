let InputNum1 = document.querySelector("#InputNum1")
let resultado2 = document.querySelector("#resultado2")
let resultado3 = document.querySelector("#resultado3")
let resultado4 = document.querySelector("#resultado4")
let resultado5 = document.querySelector("#resultado5")
let btSomar = document.querySelector("#btSomar")

function somar(){

let num1= Number(InputNum1.value);

//1%
let ovos =(num1 *2);
let gramas = Number( 0.5 * num1);
resultado2.textContent = (ovos);
resultado3.textContent = (gramas);


}

btSomar.onclick = function(){
    somar();


}