
let InputSabor1 = document.querySelector("#InputSabor1");
let InputSabor2 = document.querySelector("#InputSabor2");
let InputSabor3 = document.querySelector("#InputSabor3");
let InputSabor4 = document.querySelector("#InputSabor4");
let InputRefri = document.querySelector("#InputRefri");

let btCalcular = document.querySelector("#btCalcular");
let saboresEscolhidos = document.querySelector("#saboresEscolhidos");
let valorTotal = document.querySelector("#valorTotal");

btCalcular.onclick = function() {
    let sabor1 = InputSabor1.value;
    let sabor2 = InputSabor2.value;
    let sabor3 = InputSabor3.value;
    let sabor4 = InputSabor4.value;
    let qtdRefri = Number(InputRefri.value);

    let precoPizza = 12.00;
    let precoRefri = 7.00;

    let total = (4 * precoPizza) + (qtdRefri * precoRefri);

    saboresEscolhidos.textContent = sabor1 + ", " + sabor2 + ", " + sabor3 + ", " + sabor4;
    valorTotal.textContent = "Total: R$ " + total.toFixed(2);
}
