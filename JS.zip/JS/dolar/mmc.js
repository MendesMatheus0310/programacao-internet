let InputNum1 = document.querySelector("#InputNum1")
let resultado2 = document.querySelector("#resultado2")
let resultado3 = document.querySelector("#resultado3")
let resultado4 = document.querySelector("#resultado4")
let resultado5 = document.querySelector("#resultado5")
let btSomar = document.querySelector("#btSomar")

function somar(){

let num1= Number(InputNum1.value);

//1%
let vlrPorcentagem =(num1 * 1 / 100 );
let vlrFinal = Number(vlrPorcentagem + num1);
resultado2.textContent = (vlrFinal);

//2%
let vlrPorcentagem2 =(num1 * 2 / 100 );
let vlrFinal2 = Number(vlrPorcentagem2 + num1);
resultado3.textContent = (vlrFinal2);

//5%
let vlrPorcentagem3 =(num1 * 5 / 100 );
let vlrFinal3 = Number(vlrPorcentagem3 + num1);
resultado4.textContent = (vlrFinal3);

//10%
let vlrPorcentagem4 =(num1 * 10 / 100 );
let vlrFinal4 = Number(vlrPorcentagem4 + num1);
resultado5.textContent = (vlrFinal4);

}

btSomar.onclick = function(){
    somar();


}