let InputNum1 = document.querySelector("#InputNum1");
let InputNum2 = document.querySelector("#InputNum2");
let resultado2 = document.querySelector("#resultado2");
let resultado3 = document.querySelector("#resultado3");
let resultado4 = document.querySelector("#resultado4");
let resultado5 = document.querySelector("#resultado5");
let btSomar = document.querySelector("#btSomar");

function somar() {
    let num1 = Number(InputNum1.value);
    let num2 = Number(InputNum2.value);

    // Operações
    let Soma = num1 + num2;
    let Subtracao = num1 - num2;
    let vezes = num1 * num2;
    let divisao = num1 / num2

    resultado2.textContent = Soma;
    resultado3.textContent = Subtracao;
    resultado4.textContent = vezes;
    resultado5.textContent = divisao;
}

btSomar.onclick = somar;
