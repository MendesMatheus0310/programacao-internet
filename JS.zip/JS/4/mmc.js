//Media 
let InputNum1 = document.querySelector("#InputNum1");
let InputNum2 = document.querySelector("#InputNum2");
let InputNum3 = document.querySelector("#InputNum3");

let resultado2 = document.querySelector("#resultado2"); // Média simples
let resultado3 = document.querySelector("#resultado3"); // Média ponderada
let resultado4 = document.querySelector("#resultado4"); // Soma das médias

let btSomar = document.querySelector("#btSomar");

function somar() {
    let num1 = Number(InputNum1.value);
    let num2 = Number(InputNum2.value);
    let num3 = Number(InputNum3.value);

    let mediaSimples = (num1 + num2 + num3) / 3;
    let mediaPonderada = (num1 * 3 + num2 * 2 + num3 * 5) / 10;

    resultado2.textContent = mediaSimples;
    resultado3.textContent = mediaPonderada;
    resultado4.textContent = (mediaSimples + mediaPonderada);
    resultado5.textContent = (mediaSimples + mediaPonderada) /2 ;
}

btSomar.onclick = somar;
