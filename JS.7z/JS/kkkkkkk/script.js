let titulo = document.querySelector ("#titulo");
let CampoTexto = document.querySelector ("#CampoTexto")
let btTrocarTexto = document.querySelector ('#btTrocarTexto')

function alterarTexto() {
    // Retirando o valor digitado no input
    //e jogando na variável
    let textoDigitado = CampoTexto.value;
    // Atribuindo ao elemento titulo o texto que foi digitado
    // no input
    titulo.textContent = textoDigitado;

}
// Atribunindo uma ação de ciclar no botão
btTrocarTexto.onclick = function () {
    alterarTexto();
}