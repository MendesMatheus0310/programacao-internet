let titulo = document.querySelector ("#titulo");
let campo1 = document.querySelector ('campo1')
let campo2 = document.querySelector ('campo2')
let resultado = document.querySelector('resultado')

function somar() {
    let campo1 = document.getElementById("campo1").value;
    let campo2 = document.getElementById("campo2").value;

    let num1 = parseInt(campo1);
    let num2 = parseFloat(campo2);

    let soma = num1 + num2;

    document.getElementById("resultado").value = soma;
  }
