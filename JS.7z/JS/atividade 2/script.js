let InputNum1 = document.querySelector("#InputNum1")
let InputNum2 = document.querySelector("#InputNum2")
let resultado2 = document.querySelector("#resultado2")
let btSomar = document.querySelector("#btSomar")

function somar(){

let num1= Number(InputNum1.value);
let num2= Number(InputNum2.value);


resultado2.textContent = (num1 - num2);

}

btSomar.onclick = function(){
    somar();


}